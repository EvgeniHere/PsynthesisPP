package psynthesispp.preset;


public interface Viewable {
    Viewer viewer();
}
