package psynthesispp.preset;


public enum PlayerType {
    Human,
    RandomAI,
    SimpleAI,
    ExtendedAI,
    UpgradedAI,
    EnhancedAI,
    AdvancedAI,
    Remote
}
