package psynthesispp.preset;


import java.io.Serializable;

public enum PlayerColor implements Serializable {
    Red,
    Blue
}
